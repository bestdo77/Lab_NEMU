#ifndef __CLTD_H__
#define __CLTD_H__

make_helper(cltd_v);
make_helper(cwtl_v);

#endif
