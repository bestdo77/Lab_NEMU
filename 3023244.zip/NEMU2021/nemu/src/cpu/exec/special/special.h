#ifndef __SPECIAL_H__
#define __SPECIAL_H__

make_helper(inv);
make_helper(nemu_trap);

#endif
