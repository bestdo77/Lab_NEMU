#ifndef __MOVS_H__
#define __MOVS_H__

make_helper(movs_b);

make_helper(movs_v);

#endif
