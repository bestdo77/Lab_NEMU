#ifndef __SAR_H__
#define __SAR_H__

make_helper(sar_rm_1_b);
make_helper(sar_rm_cl_b);
make_helper(sar_rm_imm_b);

make_helper(sar_rm_1_v);
make_helper(sar_rm_cl_v);
make_helper(sar_rm_imm_v);
#endif
