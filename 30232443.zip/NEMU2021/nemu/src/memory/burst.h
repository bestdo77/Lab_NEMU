#ifndef __BURST_H__
#define __BURST_H__

#define BURST_LEN 8
#define BURST_MASK (BURST_LEN - 1)

#endif
