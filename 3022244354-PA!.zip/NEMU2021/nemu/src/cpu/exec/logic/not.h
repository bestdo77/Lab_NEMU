#ifndef __NOT_H__
#define __NOT_H__

make_helper(not_rm_b);

make_helper(not_rm_v);

#endif
